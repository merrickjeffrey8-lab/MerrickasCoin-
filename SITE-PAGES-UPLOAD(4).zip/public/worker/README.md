# MEVS 5.0 Worker (Scaffold)

This Worker is included so Auto Mode can pull real data.

## What it does
`GET /api/score?chain=<chainId>&id=<tokenId>` returns:

```json
{
  "inputs": { "verified": "...", "lpLocked": "...", "...": "..." },
  "meta": { "provider": "..." }
}
```

## Make it accurate
You must plug in *your* preferred providers per chain.
Examples (EVM): explorer APIs, DEX analytics APIs, or your own node/rpc + indexer.
Examples (Solana): RPC + token account distribution, liquidity sources, etc.

## Then
- Deploy the Worker to Cloudflare
- Set `MES_API_BASE` in `public/scripts/config.js`
