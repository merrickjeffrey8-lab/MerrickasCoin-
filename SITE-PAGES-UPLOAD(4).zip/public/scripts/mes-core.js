/**
 * MEVS 5.0 Core Scoring
 * Deterministic, neutral, conservative when unknown.
 *
 * Categories (max points):
 *  security 20
 *  liquidity 15
 *  tokenomics 15
 *  onchain 15
 *  transparency 10
 *  community 10
 *  risk 10
 *  longevity 5
 */

const MES_WEIGHTS = {"security": 20, "liquidity": 15, "tokenomics": 15, "onchain": 15, "transparency": 10, "community": 10, "risk": 10, "longevity": 5};

function clamp(n, lo, hi) { return Math.max(lo, Math.min(hi, n)); }

function scoreSecurity(inputs) {
  // Verified contract (EVM) or source available (Solana program info etc.)
  // Ownership/admin risk + optional external audit score
  let s = 0;
  // Verified
  if (inputs.verified === "yes") s += 8;
  else if (inputs.verified === "no") s += 0;
  else s += 4; // unknown -> conservative but not zero

  // Ownership
  if (inputs.ownership === "renounced") s += 6;
  else if (inputs.ownership === "owned") s += 2;
  else s += 3; // unknown

  // Audit score
  const audit = (inputs.auditScore === null) ? null : clamp(inputs.auditScore, 0, 100);
  if (audit === null) s += 3; // unknown
  else s += clamp((audit / 100) * 6, 0, 6);

  return clamp(s, 0, MES_WEIGHTS.security);
}

function scoreLiquidity(inputs) {
  let s = 0;
  if (inputs.lpLocked === "yes") s += 7;
  else if (inputs.lpLocked === "no") s += 0;
  else s += 3; // unknown

  const days = inputs.lockDays === null ? null : Math.max(0, inputs.lockDays);
  if (days === null) s += 3; // unknown
  else {
    // Curve: 0 days -> 0, 30d -> 2, 180d -> 4, 365d -> 6, 1095d -> 8
    const x = Math.log10(1 + days) / Math.log10(1 + 1095);
    s += clamp(8 * x, 0, 8);
  }
  return clamp(s, 0, MES_WEIGHTS.liquidity);
}

function scoreTokenomics(inputs) {
  let s = 0;

  // Top holder / top10 concentration
  const top = inputs.topHolderPct;
  const top10 = inputs.top10Pct;

  // We treat unknown conservatively
  if (top === null) s += 4;
  else {
    // <=2% great, <=5% good, <=10% okay, >10% risk
    if (top <= 2) s += 7;
    else if (top <= 5) s += 6;
    else if (top <= 10) s += 4;
    else s += 2;
  }

  if (top10 === null) s += 3;
  else {
    if (top10 <= 10) s += 6;
    else if (top10 <= 20) s += 5;
    else if (top10 <= 35) s += 3;
    else s += 1;
  }

  // Tax / fee
  const tax = inputs.taxPct;
  if (tax === null) s += 2;
  else {
    if (tax <= 1) s += 2;
    else if (tax <= 5) s += 1.4;
    else if (tax <= 10) s += 0.8;
    else s += 0.2;
  }

  // Mint risk
  if (inputs.mintRisk === "low") s += 1;
  else if (inputs.mintRisk === "medium") s += 0.6;
  else if (inputs.mintRisk === "high") s += 0.1;
  else s += 0.4;

  return clamp(s, 0, MES_WEIGHTS.tokenomics);
}

function scoreOnChain(inputs) {
  let s = 0;
  // Volume quality manual or from auto provider
  if (inputs.volQuality === "organic") s += 9;
  else if (inputs.volQuality === "mixed") s += 6;
  else if (inputs.volQuality === "sus") s += 2;
  else s += 5; // unknown

  // Placeholder for anomaly detection confidence
  // Auto providers may supply washTradeProb (0..1)
  if (inputs.washTradeProb !== null && inputs.washTradeProb !== undefined) {
    const p = clamp(inputs.washTradeProb, 0, 1);
    // High wash probability reduces score
    s += clamp((1 - p) * 6, 0, 6);
  } else {
    s += 4; // unknown
  }

  return clamp(s, 0, MES_WEIGHTS.onchain);
}

function scoreTransparency(inputs) {
  let s = 0;
  if (inputs.founder === "public") s += 6;
  else if (inputs.founder === "partial") s += 4;
  else if (inputs.founder === "anon") s += 1;
  else s += 3.5;

  if (inputs.docs === "strong") s += 4;
  else if (inputs.docs === "basic") s += 2.5;
  else if (inputs.docs === "weak") s += 0.7;
  else s += 2.2;

  return clamp(s, 0, MES_WEIGHTS.transparency);
}

function scoreCommunity(inputs) {
  let s = 0;
  if (inputs.community === "strong") s += 8;
  else if (inputs.community === "ok") s += 5.5;
  else if (inputs.community === "weak") s += 2;
  else s += 4.5;

  // Auto mode may provide retention (0..1)
  if (inputs.retention !== null && inputs.retention !== undefined) {
    const r = clamp(inputs.retention, 0, 1);
    s += clamp(r * 4, 0, 4);
  } else {
    s += 2;
  }
  return clamp(s, 0, MES_WEIGHTS.community);
}

function scoreRisk(inputs) {
  // Risk flags are deductions; this bucket is "how well risk is managed"
  let s = 10; // start perfect then subtract
  const flags = [];

  // Concentration risks
  if (inputs.topHolderPct !== null && inputs.topHolderPct > 10) {
    flags.push({type:"bad", text:"High whale concentration: top holder > 10%"});
    s -= 3.5;
  }
  if (inputs.top10Pct !== null && inputs.top10Pct > 35) {
    flags.push({type:"bad", text:"High concentration: top 10 holders > 35%"});
    s -= 2.5;
  }

  // Liquidity not locked
  if (inputs.lpLocked === "no") {
    flags.push({type:"bad", text:"Liquidity not locked"});
    s -= 4;
  }

  // High tax
  if (inputs.taxPct !== null && inputs.taxPct > 10) {
    flags.push({type:"bad", text:"High transaction tax/fee > 10%"});
    s -= 2.5;
  }

  // Ownership risk
  if (inputs.ownership === "owned") {
    flags.push({type:"bad", text:"Admin/upgrade risk present (ownership not minimized)"});
    s -= 2.5;
  }

  // Unknowns: add neutral flags so users know what's missing
  const unknowns = [];
  if (inputs.verified === "") unknowns.push("Contract verification unknown");
  if (inputs.lpLocked === "") unknowns.push("Liquidity lock status unknown");
  if (inputs.topHolderPct === null) unknowns.push("Top holder % unknown");
  if (inputs.top10Pct === null) unknowns.push("Top 10 holders % unknown");
  if (inputs.auditScore === null) unknowns.push("Audit score unknown");
  unknowns.forEach(u => flags.push({type:"info", text:u}));

  s = clamp(s, 0, MES_WEIGHTS.risk);
  return { score: s, flags };
}

function scoreLongevity(inputs) {
  const age = inputs.ageDays;
  if (age === null) return 2.5; // unknown
  // 0d->0.3, 30->1.2, 180->3.0, 365->4.0, 1095->5.0
  const x = Math.log10(1 + age) / Math.log10(1 + 1095);
  return clamp(5 * x, 0, MES_WEIGHTS.longevity);
}

function computeMES(inputs) {
  const sec = scoreSecurity(inputs);
  const liq = scoreLiquidity(inputs);
  const tok = scoreTokenomics(inputs);
  const onc = scoreOnChain(inputs);
  const tra = scoreTransparency(inputs);
  const com = scoreCommunity(inputs);
  const riskObj = scoreRisk(inputs);
  const lon = scoreLongevity(inputs);

  const total = sec + liq + tok + onc + tra + com + riskObj.score + lon;

  const breakdown = [
    { key:"Security", value: sec, max: MES_WEIGHTS.security },
    { key:"Liquidity", value: liq, max: MES_WEIGHTS.liquidity },
    { key:"Tokenomics", value: tok, max: MES_WEIGHTS.tokenomics },
    { key:"On-chain behavior", value: onc, max: MES_WEIGHTS.onchain },
    { key:"Transparency", value: tra, max: MES_WEIGHTS.transparency },
    { key:"Community", value: com, max: MES_WEIGHTS.community },
    { key:"Risk management", value: riskObj.score, max: MES_WEIGHTS.risk },
    { key:"Longevity", value: lon, max: MES_WEIGHTS.longevity },
  ];

  return {
    total: clamp(total, 0, 100),
    breakdown,
    flags: riskObj.flags
  };
}

function labelForScore(score) {
  if (score >= 90) return "MEVS Certified — Elite";
  if (score >= 80) return "MEVS Verified — Strong";
  if (score >= 70) return "MEVS Rated — Moderate";
  if (score >= 60) return "MEVS Caution — Needs review";
  return "MEVS High Risk — Not verified";
}
