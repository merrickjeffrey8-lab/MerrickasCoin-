
(function(){
  const el = (id) => document.getElementById(id);

  const RPC = {
    ethereum: ["https://cloudflare-eth.com"],
    base: ["https://mainnet.base.org"],
    arbitrum: ["https://arb1.arbitrum.io/rpc"],
    optimism: ["https://mainnet.optimism.io"],
    polygon: ["https://polygon-rpc.com"],
    bnb: ["https://bsc-dataseed.binance.org"],
    avalanche: ["https://api.avax.network/ext/bc/C/rpc"],
    fantom: ["https://rpc.ftm.tools"]
  };

  function isHexAddr(x){
    return /^0x[a-fA-F0-9]{40}$/.test((x||"").trim());
  }

  async function rpcFetch(url, method, params){
    const body = JSON.stringify({jsonrpc:"2.0", id:1, method, params});
    const res = await fetch(url, {
      method:"POST",
      headers: {"content-type":"application/json"},
      body,
      cache:"no-store"
    });
    const j = await res.json();
    if(j.error) throw new Error(j.error.message || "RPC error");
    return j.result;
  }

  async function rpcAny(chainId, method, params){
    const urls = RPC[chainId] || [];
    let lastErr = null;
    for(const u of urls){
      try { return await rpcFetch(u, method, params); }
      catch(e){ lastErr = e; }
    }
    throw lastErr || new Error("No RPC available");
  }

  function pad64(hex){ return hex.replace(/^0x/,"").padStart(64,"0"); }
  function hexToBytes(hex){
    const h = hex.replace(/^0x/,"");
    const out = new Uint8Array(h.length/2);
    for(let i=0;i<out.length;i++) out[i] = parseInt(h.slice(i*2,i*2+2),16);
    return out;
  }
  function bytesToAscii(bytes){
    let s="";
    for(const b of bytes){
      if(b===0) break;
      if(b>=32 && b<=126) s+=String.fromCharCode(b);
    }
    return s.trim();
  }
  function decodeUint(hex){
    return BigInt(hex);
  }
  function decodeString(ret){
    // Handle bytes32-as-string
    try{
      if(ret.length === 66){ // 32 bytes
        return bytesToAscii(hexToBytes(ret));
      }
      const data = ret.replace(/^0x/,"");
      if(data.length < 128) return "";
      const offset = parseInt(data.slice(0,64),16) * 2;
      const len = parseInt(data.slice(offset, offset+64),16) * 2;
      const strHex = data.slice(offset+64, offset+64+len);
      const bytes = hexToBytes("0x"+strHex);
      return new TextDecoder().decode(bytes).replace(/\0/g,"").trim();
    } catch {
      return "";
    }
  }

  const SEL = {
    name: "0x06fdde03",
    symbol: "0x95d89b41",
    decimals: "0x313ce567",
    totalSupply: "0x18160ddd",
    owner: "0x8da5cb5b"
  };

  async function ethCall(chainId, to, data){
    return await rpcAny(chainId, "eth_call", [{to, data}, "latest"]);
  }

  async function readEvmBasics(chainId, addr){
    const code = await rpcAny(chainId, "eth_getCode", [addr, "latest"]);
    if(!code || code === "0x") throw new Error("No contract code at address");

    const [nameR, symR, decR, supR] = await Promise.all([
      ethCall(chainId, addr, SEL.name).catch(()=> "0x"),
      ethCall(chainId, addr, SEL.symbol).catch(()=> "0x"),
      ethCall(chainId, addr, SEL.decimals).catch(()=> "0x"),
      ethCall(chainId, addr, SEL.totalSupply).catch(()=> "0x")
    ]);

    const name = nameR !== "0x" ? decodeString(nameR) : "";
    const symbol = symR !== "0x" ? decodeString(symR) : "";
    let decimals = null;
    try{
      if(decR && decR !== "0x"){
        decimals = Number(decodeUint(decR));
      }
    }catch{}
    let totalSupply = null;
    try{
      if(supR && supR !== "0x"){
        totalSupply = decodeUint(supR);
      }
    }catch{}

    // owner() best-effort
    let owner = "";
    try{
      const ownR = await ethCall(chainId, addr, SEL.owner);
      if(ownR && ownR !== "0x" && ownR.length >= 66){
        owner = "0x" + ownR.slice(-40);
      }
    }catch{}

    return {name, symbol, decimals, totalSupply, owner};
  }

  function fmtSupply(totalSupply, decimals){
    if(totalSupply==null) return "";
    if(decimals==null) return totalSupply.toString();
    // Format with decimals (rough, trimmed)
    const s = totalSupply.toString();
    if(decimals === 0) return s;
    const pad = decimals;
    const whole = s.length > pad ? s.slice(0, s.length-pad) : "0";
    const frac = s.length > pad ? s.slice(s.length-pad) : s.padStart(pad,"0");
    const fracTrim = frac.replace(/0+$/,"").slice(0,6);
    return fracTrim ? `${whole}.${fracTrim}` : whole;
  }

  function showStatus(msg, good=false){
    const s = el("autoReadStatus");
    if(!s) return;
    s.textContent = msg;
    s.style.opacity = "1";
  }
  function showDetails(html){
    const card = el("autoReadCard");
    const d = el("autoReadDetails");
    if(!card || !d) return;
    d.innerHTML = html;
    card.classList.remove("hidden");
  }

  async function onAutoRead(){
    const chainSel = el("chainSelect");
    const chainId = chainSel?.value || "";
    const tokenId = (el("tokenId")?.value || "").trim();

    if(!chainId){
      showStatus("Select a chain first.", false);
      return;
    }
    if(chainId === "solana"){
      showStatus("Auto‑read supports EVM chains first. Use Manual for Solana.", false);
      return;
    }
    if(!isHexAddr(tokenId)){
      showStatus("Paste a valid 0x contract address.", false);
      return;
    }
    showStatus("Reading contract…", true);

    try{
      const info = await readEvmBasics(chainId, tokenId);
      const supplyFmt = fmtSupply(info.totalSupply, info.decimals);
      const ownerLine = info.owner ? info.owner : "Not detected (non‑Ownable or custom).";

      showStatus("Contract matched ✔", true);
      showDetails(`
        <div><b>${info.name || "Unknown name"}</b> ${info.symbol ? `(${info.symbol})` : ""}</div>
        <div class="muted small">Decimals: ${info.decimals ?? "?"} • Total supply: ${supplyFmt || "?"}</div>
        <div class="muted small">owner(): ${ownerLine}</div>
        <div class="muted small">Note: This is read‑only and costs <b>$0 gas</b>.</div>
      `);

      // Optional: if token name/symbol missing, keep manual.
      // We don't overwrite scoring inputs automatically to avoid wrong assumptions.
    }catch(e){
      showStatus("Auto‑read failed: "+ (e?.message || "error"), false);
    }
  }

  window.addEventListener("load", ()=>{
    const btn = el("btnAutoRead");
    if(btn){
      btn.addEventListener("click", onAutoRead);
    }
  });
})();
