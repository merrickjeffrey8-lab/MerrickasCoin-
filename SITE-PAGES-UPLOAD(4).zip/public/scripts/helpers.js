function copyText(text) {
  return navigator.clipboard.writeText(text).then(() => true).catch(() => false);
}

function toast(msg) {
  const t = document.createElement("div");
  t.className = "toast";
  t.textContent = msg;
  document.body.appendChild(t);
  setTimeout(() => t.classList.add("show"), 10);
  setTimeout(() => {
    t.classList.remove("show");
    setTimeout(() => t.remove(), 250);
  }, 1800);
}

function wireCopyButtons() {
  document.querySelectorAll("[data-copy]").forEach(btn => {
    btn.addEventListener("click", async () => {
      const text = btn.getAttribute("data-copy");
      const ok = await copyText(text);
      toast(ok ? "Copied" : "Copy failed");
    });
  });
}

window.addEventListener("load", wireCopyButtons);
