
async function sha256Hex(str) {
  const enc = new TextEncoder();
  const buf = await crypto.subtle.digest("SHA-256", enc.encode(str));
  return [...new Uint8Array(buf)].map(b => b.toString(16).padStart(2,"0")).join("");
}
function canonicalize(obj){
  // stable JSON stringify with sorted keys
  const allKeys = [];
  JSON.stringify(obj, (k,v) => (allKeys.push(k), v));
  allKeys.sort();
  return JSON.stringify(obj, allKeys, 0);
}
function fmt(ts){
  try { return new Date(ts).toLocaleString(); } catch { return ts; }
}
function el(tag, attrs={}, children=[]){
  const e=document.createElement(tag);
  Object.entries(attrs).forEach(([k,v])=>{
    if(k==="class") e.className=v;
    else if(k==="html") e.innerHTML=v;
    else e.setAttribute(k,v);
  });
  children.forEach(c=>e.appendChild(typeof c==="string"?document.createTextNode(c):c));
  return e;
}

async function loadRegistry(){
  const status = document.querySelector("#regStatus");
  const list = document.querySelector("#regList");
  const details = document.querySelector("#regDetails");
  status.textContent = "Loading registry…";

  const res = await fetch("/registry/chain.json", {cache:"no-store"});
  if(!res.ok){ status.textContent="Registry load failed."; return; }
  const chain = await res.json();

  // Verify chain
  let ok=true;
  let prev = "0".repeat(64);
  for(const b of chain.blocks){
    if(b.prev_hash !== prev){ ok=false; break; }
    prev = b.receipt_hash;
  }
  status.textContent = ok ? "Registry verified (hash chain intact)." : "Registry WARNING: hash chain mismatch.";

  // Render list
  list.innerHTML="";
  chain.blocks.slice().reverse().forEach((b)=>{
    const row = el("div",{class:"row"},[
      el("div",{class:"left"},[
        el("div",{class:"token"},[`${b.score.toFixed(2)} • ${b.tier}`]),
        el("div",{class:"muted"},[`Contract: ${b.token_contract}`]),
        el("div",{class:"muted small"},[`Time: ${fmt(b.timestamp_utc)}`]),
      ]),
      el("button",{class:"btn", "data-file": b.receipt_file},["View receipt"])
    ]);
    row.querySelector("button").addEventListener("click", ()=>showReceipt(b.receipt_file, b.receipt_hash, b.prev_hash));
    list.appendChild(row);
  });

  // Auto-open latest
  if(chain.blocks.length){
    const latest = chain.blocks[chain.blocks.length-1];
    await showReceipt(latest.receipt_file, latest.receipt_hash, latest.prev_hash);
  }

  async function showReceipt(file, expectedHash, expectedPrev){
    details.innerHTML="Loading receipt…";
    const r = await fetch("/"+file, {cache:"no-store"});
    if(!r.ok){ details.innerHTML="Receipt load failed."; return; }
    const receipt = await r.json();

    // verify prev hash + receipt hash
    const prevHash = receipt?._meta?.prev_hash ?? "";
    const canon = canonicalize(receipt);
    const gotHash = await sha256Hex(canon);

    const goodPrev = (prevHash === expectedPrev);
    const goodHash = (gotHash === expectedHash);

    const badge = (ok && goodPrev && goodHash) ? "✅ Verified" : "⚠️ Unverified";
    const box = el("div",{class:"card glow"},[
      el("h2",{},["MEVS Public Receipt ", el("span",{class:"pill"},[badge])]),
      el("div",{class:"grid"},[
        el("div",{class:"kv"},[el("div",{class:"k"} ,["Token"]), el("div",{class:"v"},[receipt.token.name])]),
        el("div",{class:"kv"},[el("div",{class:"k"} ,["Chain"]), el("div",{class:"v"},[receipt.token.chain])]),
        el("div",{class:"kv"},[el("div",{class:"k"} ,["Contract"]), el("div",{class:"v mono"},[receipt.token.contract])]),
        el("div",{class:"kv"},[el("div",{class:"k"} ,["Score"]), el("div",{class:"v"},[`${receipt.result.score} (${receipt.result.tier})`])]),
      ]),
      el("div",{class:"actions"},[
        el("a",{class:"btn",href: receipt.links.basescan, target:"_blank", rel:"noreferrer"},["Open BaseScan"]),
        el("a",{class:"btn",href: receipt.links.dextools_pair, target:"_blank", rel:"noreferrer"},["Open DEXTools"]),
        el("button",{class:"btn",id:"copyContract"},["Copy contract"]),
        el("button",{class:"btn",id:"copyHash"},["Copy receipt hash"]),
      ]),
      el("div",{class:"divider"}),
      el("div",{class:"muted"},["Receipt hash (SHA-256):"]),
      el("div",{class:"mono small wrap"},[gotHash]),
      el("div",{class:"muted small"},[
        `Prev hash: ${expectedPrev}`,
        " • ",
        `Prev match: ${goodPrev ? "Yes" : "No"}`,
        " • ",
        `Hash match: ${goodHash ? "Yes" : "No"}`
      ]),
      el("div",{class:"divider"}),
      el("details",{},[
        el("summary",{},["Show inputs"]),
        el("pre",{class:"pre"},[JSON.stringify(receipt.inputs, null, 2)])
      ]),
      el("details",{},[
        el("summary",{},["Show full receipt JSON"]),
        el("pre",{class:"pre"},[JSON.stringify(receipt, null, 2)])
      ])
    ]);

    details.innerHTML="";
    details.appendChild(box);

    details.querySelector("#copyContract").onclick = async ()=>{
      await navigator.clipboard.writeText(receipt.token.contract);
      details.querySelector("#copyContract").textContent="Copied ✔";
      setTimeout(()=>details.querySelector("#copyContract").textContent="Copy contract", 900);
    };
    details.querySelector("#copyHash").onclick = async ()=>{
      await navigator.clipboard.writeText(gotHash);
      details.querySelector("#copyHash").textContent="Copied ✔";
      setTimeout(()=>details.querySelector("#copyHash").textContent="Copy receipt hash", 900);
    };
  }
}

window.addEventListener("load", ()=>{
  const page = document.body.getAttribute("data-page");
  if(page==="registry") loadRegistry().catch(()=>{
    const s=document.querySelector("#regStatus");
    if(s) s.textContent="Registry error loading.";
  });
});
