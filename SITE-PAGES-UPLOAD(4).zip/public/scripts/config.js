window.SITE_BUILD = "coin-first-abslinks-v1";
// MEVS 5.0 Config
// If you deploy the included Cloudflare Worker, set MES_API_BASE to your worker URL (no trailing slash).
// Example: https://mes5-api.yourdomain.workers.dev
const MES_API_BASE = ""; // <-- set me to enable Auto mode
