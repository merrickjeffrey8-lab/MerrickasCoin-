// Visitor tracking retired. Completed audits are counted by /scripts/audit-counter.js.
