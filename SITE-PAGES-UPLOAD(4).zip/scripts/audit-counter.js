(() => {
  const endpoint = '/api/mrc-site-visits';
  const prefix = 'mevs_pending_audit_v1_';
  const pending = new Map();
  try {
    for (let i = 0; i < localStorage.length; i++) {
      const key = localStorage.key(i);
      if (!key?.startsWith(prefix)) continue;
      const receipt = JSON.parse(localStorage.getItem(key));
      if (receipt?.runId) pending.set(receipt.runId, receipt);
    }
  } catch { /* Completed audits can still be reported without browser storage. */ }
  let participantId;
  try {
    participantId = localStorage.getItem('mevs_participant_v1');
    if (!/^[0-9a-f-]{36}$/i.test(participantId || '')) {
      participantId = crypto.randomUUID();
      localStorage.setItem('mevs_participant_v1', participantId);
    }
  } catch { participantId = crypto.randomUUID(); }
  let flushing = false;

  function display(total, counter = {}) {
    if (!Number.isSafeInteger(total) || total < 0) return;
    document.querySelectorAll('[data-mevs-audit-count]').forEach(panel => {
      panel.querySelector('output').textContent = total.toLocaleString();
      panel.hidden = false;
      const browsers = panel.querySelector('[data-mevs-browser-count]');
      if (browsers && Number.isSafeInteger(counter.participatingBrowsers)) {
        browsers.textContent = counter.participatingBrowsers.toLocaleString();
      }
    });
  }

  async function flush() {
    if (flushing) return;
    flushing = true;
    try {
      const check = await fetch(endpoint, {
        cache: 'no-store', signal: AbortSignal.timeout(10000)
      });
      if (!check.ok) return;
      const counter = await check.json();
      if (counter.metric !== 'completed_audit_runs') return;
      display(counter.total, counter);
      for (const [runId, receipt] of pending) {
        const response = await fetch(endpoint, {
          method: 'POST', headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify(receipt), signal: AbortSignal.timeout(10000)
        });
        if (!response.ok) break;
        const result = await response.json();
        if (result.metric !== 'completed_audit_runs') break;
        display(result.total, result);
        pending.delete(runId);
        try { localStorage.removeItem(prefix + runId); }
        catch { /* Server receipt IDs prevent retries from counting twice. */ }
      }
    } catch { /* Retry the original receipt when connectivity returns. */ }
    finally { flushing = false; }
  }

  window.recordMevsAudit = ({ token, chain, score, mode, tier, scoringVersion }) => {
    if (!token || !Number.isFinite(score) || score < 0 || score > 100) return;
    const runId = crypto.randomUUID();
    const receipt = { runId, participantId, token, chain: String(chain), score, mode,
      tier: tier || 'Not recorded', scoringVersion: scoringVersion || 'Not recorded',
      completedAt: new Date().toISOString() };
    pending.set(runId, receipt);
    try { localStorage.setItem(prefix + runId, JSON.stringify(receipt)); }
    catch { /* Retain this receipt in memory if browser storage is unavailable. */ }
    void flush();
  };
  try {
    const historical = JSON.parse(localStorage.getItem('mevs_receipts') || '[]');
    if (Array.isArray(historical)) {
      for (const original of historical) {
        if (!original || !/^[0-9a-f]{64}$/i.test(original.receiptId || '') ||
            !Number.isFinite(original.score) || original.score < 0 || original.score > 100 ||
            !original.address || !original.chainKey || !Number.isFinite(Date.parse(original.ts))) continue;
        const hex = original.receiptId.slice(0, 32);
        const runId = `${hex.slice(0,8)}-${hex.slice(8,12)}-${hex.slice(12,16)}-${hex.slice(16,20)}-${hex.slice(20)}`;
        const receipt = { runId, participantId, token: original.address, chain: String(original.chainKey),
          score: original.score, mode: 'phase1', tier: original.grade || 'Not recorded',
          scoringVersion: original.version || 'Not recorded', completedAt: new Date(original.ts).toISOString(),
          originalReceiptId: original.receiptId, originalReceiptHash: original.hash || null,
          source: 'saved_phase1_receipt' };
        if (!pending.has(runId)) {
          pending.set(runId, receipt);
          try { localStorage.setItem(prefix + runId, JSON.stringify(receipt)); }
          catch { /* The original mevs_receipts data is retained. */ }
        }
      }
    }
  } catch { /* Keep original browser records intact if an entry cannot be read. */ }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', flush);
  else void flush();
  window.addEventListener('online', flush);
})();
