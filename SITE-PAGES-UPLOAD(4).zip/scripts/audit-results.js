(async () => {
  const status = document.getElementById('auditResultsStatus');
  const rows = document.getElementById('auditResultsRows');
  const more = document.getElementById('auditResultsMore');
  let cursor = null;

  function cell(text) {
    const element = document.createElement('td');
    element.textContent = text == null ? 'Not recorded' : String(text);
    return element;
  }

  async function load(reset = false) {
    more.disabled = true;
    status.textContent = 'Loading saved audit results…';
    try {
      const query = new URLSearchParams({ view: 'records' });
      if (!reset && cursor != null) query.set('before', String(cursor));
      const response = await fetch('/api/mrc-site-visits?' + query, { cache: 'no-store' });
      if (!response.ok) throw new Error('Audit service unavailable');
      const data = await response.json();
      if (data.metric !== 'completed_audit_runs' || !Array.isArray(data.records)) {
        throw new Error('Audit recording service needs the matching Worker update');
      }
      if (reset) rows.replaceChildren();
      for (const record of data.records) {
        const row = document.createElement('tr');
        row.append(cell(record.token), cell(record.chain), cell(record.score),
          cell(record.tier), cell(record.mode), cell(record.scoring_version),
          cell(record.completed_at || record.recorded_at + ' UTC'));
        const receiptCell = document.createElement('td');
        const link = document.createElement('a');
        link.href = '/api/mrc-site-visits?receipt=' + encodeURIComponent(record.run_id);
        link.textContent = 'Receipt';
        const badge = document.createElement('a');
        badge.href = '/api/mrc-site-visits?badge=' + encodeURIComponent(record.run_id);
        badge.textContent = 'Share badge';
        receiptCell.append(link, document.createTextNode(' · '), badge);
        row.appendChild(receiptCell);
        rows.appendChild(row);
      }
      document.getElementById('auditTotal').textContent = data.total.toLocaleString();
      document.getElementById('auditParticipants').textContent = data.participatingBrowsers.toLocaleString();
      cursor = data.next;
      more.hidden = cursor == null;
      status.textContent = data.total ? `${data.total} saved audit runs. Latest records appear first.`
        : 'No new audit runs have been recorded yet. Historical records are linked below.';
      if (data.runsWithoutParticipant) status.textContent += ` ${data.runsWithoutParticipant} older runs have no browser identifier.`;
    } catch (error) {
      status.textContent = error.message + '. Existing saved records have not been changed.';
    } finally { more.disabled = false; }
  }
  more.addEventListener('click', () => load());
  document.getElementById('auditResultsRefresh').addEventListener('click', () => load(true));
  await load(true);
})();
