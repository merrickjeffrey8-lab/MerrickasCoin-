MEVS 5.0 — Cloudflare Pages (ROOT ZIP)

This ZIP is flattened so Cloudflare Pages can serve it immediately:
- index.html is at the ZIP root
- /styles, /scripts, /assets, /pages, etc. are at root

Cloudflare Pages settings:
- Framework preset: None
- Build command: (leave blank)
- Output directory: (leave blank) OR "/"
