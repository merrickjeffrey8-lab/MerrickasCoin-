const CACHE = "mes5-cache-v1";
const ASSETS = [
  "/", "/index.html",
  "/styles/app.css",
  "/scripts/config.js",
  "/scripts/MEVS-core.js",
  "/scripts/app.js",
  "/data/chains.json",
  "/assets/icon.svg",
  "/assets/badges/MEVS-badge-placeholder.svg",
  "/assets/badges/MEVS-badge-elite.svg",
  "/assets/badges/MEVS-badge-strong.svg",
  "/assets/badges/MEVS-badge-moderate.svg",
  "/assets/badges/MEVS-badge-caution.svg",
  "/assets/badges/MEVS-badge-risk.svg",
  "/pages/methodology.html",
  "/pages/badges.html",
  "/pages/disputes.html",
  "/pages/api.html",
  "/pages/token.html",
  "/pages/MEVS.html",
  "/scripts/helpers.js"
];

self.addEventListener("install", (e) => {
  e.waitUntil(caches.open(CACHE).then(c => c.addAll(ASSETS)).then(() => self.skipWaiting()));
});

self.addEventListener("activate", (e) => {
  e.waitUntil(self.clients.claim());
});

self.addEventListener("fetch", (e) => {
  const url = new URL(e.request.url);
  if (url.pathname.startsWith("/api/")) return; // don't cache API
  e.respondWith(
    caches.match(e.request).then(cached => cached || fetch(e.request).then(resp => {
      const copy = resp.clone();
      caches.open(CACHE).then(c => c.put(e.request, copy));
      return resp;
    }).catch(()=>cached))
  );
});
