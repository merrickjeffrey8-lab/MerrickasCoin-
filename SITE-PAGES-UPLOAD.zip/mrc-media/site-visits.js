(async () => {
  const counter = document.querySelector('[data-mrc-site-visits]');
  if (!counter) return;

  const sessionKey = 'mrc-homepage-counted';
  let counted = false;
  try {
    counted = sessionStorage.getItem(sessionKey) === '1';
  } catch {
    // Storage can be disabled in the browser.
  }

  try {
    const response = await fetch('/api/mrc-site-visits', {
      method: counted ? 'GET' : 'POST',
      cache: 'no-store',
      headers: { Accept: 'application/json' }
    });
    if (!response.ok) return;
    const { total } = await response.json();
    if (!Number.isSafeInteger(total) || total < 0) return;

    counter.querySelector('output').textContent = total.toLocaleString();
    counter.hidden = false;
    try {
      sessionStorage.setItem(sessionKey, '1');
    } catch {
      // The shared total is still available without browser storage.
    }
  } catch {
    // Leave the counter hidden when the API is unavailable.
  }
})();
