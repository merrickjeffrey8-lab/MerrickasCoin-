const el = (id) => document.getElementById(id);

const state = {
  mode: "manual",
  lastResult: null,
  chain: null
};

async function loadChains() {
  const res = await fetch("/data/chains.json");
  const chains = await res.json();
  const sel = el("chainSelect");
  sel.innerHTML = "";
  for (const c of chains) {
    const opt = document.createElement("option");
    opt.value = c.id;
    opt.textContent = `${c.name}`;
    sel.appendChild(opt);
  }
  state.chain = sel.value;
  sel.addEventListener("change", () => { state.chain = sel.value; });
}

function setMode(mode) {
  state.mode = mode;
  el("modeManual").classList.toggle("active", mode === "manual");
  el("modeAuto").classList.toggle("active", mode === "auto");
  el("autoHint").classList.toggle("hidden", !(mode === "auto" && !MES_API_BASE));
}

function getInputsFromForm() {
  const num = (v) => (v === "" || v === null || v === undefined) ? null : Number(v);
  return {
    chainId: state.chain,
    tokenId: el("tokenId").value.trim(),
    verified: el("inVerified").value,
    ownership: el("inOwnership").value,
    auditScore: num(el("inAudit").value),
    lpLocked: el("inLpLocked").value,
    lockDays: num(el("inLockDays").value),
    topHolderPct: num(el("inTopHolder").value),
    top10Pct: num(el("inTop10").value),
    taxPct: num(el("inTax").value),
    mintRisk: el("inMintRisk").value,
    ageDays: num(el("inAge").value),
    volQuality: el("inVolQuality").value,
    founder: el("inFounder").value,
    docs: el("inDocs").value,
    community: el("inCommunity").value,
    // optional auto-only fields
    washTradeProb: null,
    retention: null
  };
}

function renderResult(result) {
  state.lastResult = result;

  const score = result.total;
  el("scoreValue").innerText = score.toFixed(2);
  const label = labelForScore(score);
  el("scoreLabel").innerText = label;

  // Gauge
  const gf = document.getElementById("gaugeFill");
  const gt = document.getElementById("gaugeTxt");
  if (gt) gt.textContent = score.toFixed(0);
  if (gf) {
    gf.style.opacity = "1";
    // 0..100 -> 0..360 degrees
    const deg = Math.max(0, Math.min(360, (score / 100) * 360));
    gf.style.transform = `rotate(${deg}deg)`;
    // Color tier (subtle)
    const tier = score >= 90 ? "rgba(54,211,153,0.55)" : score >= 80 ? "rgba(77,163,255,0.55)" : score >= 70 ? "rgba(251,191,36,0.55)" : "rgba(251,113,133,0.50)";
    gf.style.borderColor = tier;
  }


  const bd = el("breakdown");
  bd.innerHTML = "";
  for (const m of result.breakdown) {
    const div = document.createElement("div");
    div.className = "metric";
    const pct = Math.max(0, Math.min(100, (m.value / m.max) * 100));
    div.innerHTML = `<div class="metricTop"><b>${m.key}</b><span>${m.value.toFixed(2)} / ${m.max}</span></div><div class="bar"><div style="width:${pct}%"></div></div>`;
    bd.appendChild(div);
  }

  const flags = el("flags");
  flags.innerHTML = "";
  if (!result.flags || result.flags.length === 0) {
    const d = document.createElement("div");
    d.className = "flag";
    d.textContent = "No flags.";
    flags.appendChild(d);
  } else {
    for (const f of result.flags) {
      const d = document.createElement("div");
      d.className = "flag" + (f.type === "bad" ? " bad" : "");
      d.textContent = f.text;
      flags.appendChild(d);
    }
  }

  // Badge selection based on score range
  let badge = "MEVS-badge-risk.svg";
  if (score >= 90) badge = "MEVS-badge-elite.svg";
  else if (score >= 80) badge = "MEVS-badge-strong.svg";
  else if (score >= 70) badge = "MEVS-badge-moderate.svg";
  else if (score >= 60) badge = "MEVS-badge-caution.svg";
  el("badgeImg").src = `assets/badges/${badge}`;

  el("btnDownloadReport").disabled = false;
  el("btnCopyJson").disabled = false;
}

async function scoreManual() {
  const inputs = getInputsFromForm();
  const result = computeMES(inputs);
  renderResult(result);
}

async function scoreAuto() {
  const inputs = getInputsFromForm();
  if (!MES_API_BASE) {
    // Fall back to manual with warning
    el("autoHint").classList.remove("hidden");
    const result = computeMES(inputs);
    renderResult(result);
    return;
  }
  if (!inputs.tokenId) {
    alert("Enter a token identifier (contract or mint address) for Auto mode.");
    return;
  }
  // Worker endpoint expected:
  // GET /api/score?chain=<chainId>&id=<tokenId>
  const url = `${MES_API_BASE}/api/score?chain=${encodeURIComponent(inputs.chainId)}&id=${encodeURIComponent(inputs.tokenId)}`;
  const resp = await fetch(url);
  if (!resp.ok) {
    const txt = await resp.text();
    console.warn(txt);
    alert("Auto mode failed (check Worker config). Scoring with manual inputs instead.");
    const result = computeMES(inputs);
    renderResult(result);
    return;
  }
  const autoData = await resp.json();
  // Merge auto fields onto manual inputs
  const merged = { ...inputs, ...autoData.inputs };
  const result = computeMES(merged);
  result.meta = autoData.meta;
  renderResult(result);
}

function resetForm() {
  for (const id of ["tokenId","inAudit","inLockDays","inTopHolder","inTop10","inTax","inAge"]) {
    el(id).value = "";
  }
  for (const id of ["inVerified","inOwnership","inLpLocked","inMintRisk","inVolQuality","inFounder","inDocs","inCommunity"]) {
    el(id).value = "";
  }
  el("scoreValue").innerText = "--";
  const gf = document.getElementById("gaugeFill");
  const gt = document.getElementById("gaugeTxt");
  if (gt) gt.textContent = "--";
  if (gf) { gf.style.opacity = "0"; gf.style.transform = "rotate(0deg)"; }
  el("scoreLabel").innerText = "No score yet";
  el("breakdown").innerHTML = "";
  el("flags").innerHTML = "";
  el("badgeImg").src = "assets/badges/MEVS-badge-placeholder.svg";
  el("btnDownloadReport").disabled = true;
  el("btnCopyJson").disabled = true;
  state.lastResult = null;
}

function downloadReport() {
  if (!state.lastResult) return;
  const now = new Date().toISOString();
  const chain = state.chain;
  const inputs = getInputsFromForm();

  const html = `<!doctype html>
<html><head><meta charset="utf-8"/><meta name="viewport" content="width=device-width, initial-scale=1"/>
<title>MEVS 5.0 Report</title>
<style>
body{font-family:Arial,Helvetica,sans-serif;margin:24px;color:#0b1220;}
h1{margin:0 0 8px 0;} .muted{color:#475569;}
.box{border:1px solid #cbd5e1;border-radius:12px;padding:14px;margin:12px 0;}
.row{display:flex;justify-content:space-between;padding:8px 0;border-bottom:1px solid #e2e8f0;}
.row:last-child{border-bottom:none;}
.bad{color:#b91c1c;}
code{background:#f1f5f9;padding:2px 6px;border-radius:8px;}
</style>
</head><body>
<h1>MEVS 5.0 Integrity Report</h1>
<div class="muted">Generated: ${now}</div>
<div class="box">
  <div><b>Chain:</b> ${chain}</div>
  <div><b>Token ID:</b> <code>${(inputs.tokenId||"(manual)")}</code></div>
  <div><b>Total Score:</b> ${state.lastResult.total.toFixed(2)} — ${labelForScore(state.lastResult.total)}</div>
</div>

<div class="box">
  <h2>Breakdown</h2>
  ${state.lastResult.breakdown.map(m=>`<div class="row"><div>${m.key}</div><div>${m.value.toFixed(2)} / ${m.max}</div></div>`).join("")}
</div>

<div class="box">
  <h2>Risk Flags</h2>
  ${(state.lastResult.flags && state.lastResult.flags.length)
    ? state.lastResult.flags.map(f=>`<div class="${f.type==="bad"?"bad":""}">• ${f.text}</div>`).join("")
    : "<div>None</div>"}
</div>

<div class="box">
  <h2>Methodology</h2>
  <div class="muted">This report uses the published MEVS 5.0 deterministic scoring rules and conservative defaults for unknown inputs.</div>
</div>

</body></html>`;

  const blob = new Blob([html], { type: "text/html" });
  const a = document.createElement("a");
  a.href = URL.createObjectURL(blob);
  a.download = `MES5_Report_${chain}_${(inputs.tokenId||"manual").slice(0,12)}.html`;
  a.click();
  URL.revokeObjectURL(a.href);
}

async function copyJson() {
  if (!state.lastResult) return;
  const payload = {
    chain: state.chain,
    inputs: getInputsFromForm(),
    result: state.lastResult
  };
  await navigator.clipboard.writeText(JSON.stringify(payload, null, 2));
  alert("Copied JSON to clipboard.");
}

window.addEventListener("load", async () => {
  await loadChains();

  el("modeManual").addEventListener("click", () => setMode("manual"));
  el("modeAuto").addEventListener("click", () => setMode("auto"));
  setMode("manual");

  el("btnScore").addEventListener("click", () => {
    if (state.mode === "auto") scoreAuto();
    else scoreManual();
  });
  el("btnReset").addEventListener("click", resetForm);
  el("btnDownloadReport").addEventListener("click", downloadReport);
  el("btnCopyJson").addEventListener("click", copyJson);

  // PWA
  if ("serviceWorker" in navigator) {
    navigator.serviceWorker.register("sw.js").catch(()=>{});
  }
});
